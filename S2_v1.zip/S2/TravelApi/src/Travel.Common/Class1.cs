﻿using System;

namespace Travel.Common
{
    public class Class1
    {
    }
}
