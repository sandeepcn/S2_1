using System;

namespace Travel.Common.Commands
{
    public class CreateTrip : IAuthenticatedCommand
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public string Name { get; set; }
        public string DriverName { get; set; }
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public DateTime TripTime { get; set; }

    }
}