namespace Travel.Common.Commands
{
    public interface ICommand
    {
         
    }
}