namespace Travel.Common.Events
{
    public interface IEvent
    {         
    }
}