using System;

namespace Travel.Common.Events
{
    public class TripCreated : IAuthenticatedEvent
    {

        public Guid Id { get; }
        public Guid UserId { get; }
        public string Name { get; }
        public string DriverName { get; }
        public string FromLocation { get; }
        public string ToLocation { get; }
        public DateTime TripTime { get; }

        protected TripCreated()
        {
        }
        public TripCreated(Guid id, Guid userId, string name, string driverName, string fromLocation, string toLocation, DateTime tripTime)
        {
            Id = id;
            UserId = userId;
            Name = name;
            DriverName = driverName;
            FromLocation = fromLocation;
            ToLocation = toLocation;
            TripTime = tripTime;
        }



    }
}